# CampusFlow AI 🚀
> **Intelligent Campus Service Discovery, Transparent Wait Time Estimation & Regulated Emergency Quota Orchestrator**

Built for the AWS Campus Innovation Hackathon addressing the problem statement: **“The Appointment That Took All Morning.”**

---

## 🌟 Overview
CampusFlow AI eliminates campus administrative confusion and unbalanced physical lines by providing:
1. **AI Service Navigator**: Powered by **Amazon Bedrock (Anthropic Claude 3 Sonnet)** to extract structured intent, urgency, and deadlines from student natural language without hallucinating campus operational facts.
2. **Authoritative Ground Truth**: Retrieves exact building, room, counter, active staff, and required document checklists from **Amazon DynamoDB**.
3. **Regulated Emergency Priority Engine**: Strictly limits emergency queue skipping to **2–3 protected slots per service per day** (for visa, passport, travel, and scholarship deadlines), requiring mandatory justification, verifiable deadlines, and S3 supporting document verification.
4. **Transparent Waiting Times**: Deterministic calculation based on active waiting students, average service duration, and active counters.
5. **Unified Role Portals**: Dedicated **Student Navigator**, **Staff Counter Workspace**, and **Admin Quota Control**.
6. **100% Digital Fulfillment**: S3 pre-signed upload flow for eligible paperless requests.

---

## 🏛️ AWS Serverless Architecture
- **Frontend**: Vite + React + Modern Glassmorphic Theme
- **API Gateway**: REST APIs with CORS
- **Compute**: AWS Lambda (Python 3.11)
- **AI/LLM**: Amazon Bedrock (`anthropic.claude-3-sonnet`)
- **Database**: Amazon DynamoDB (`Services`, `Queues`, `EmergencyRequests`, `Appointments`, `Staff`, `DigitalRequests`)
- **Storage**: Amazon S3 (Student Supporting Documents with Pre-signed URLs)
- **IaC**: AWS Serverless Application Model (SAM)

---

## ⚡ Quick Start (Run Locally)

### 1. Launch Frontend
```bash
cd frontend
npm install
npm run dev
```
Open **`http://localhost:3000`** in your browser.

### 2. (Optional) Launch Local Python Server
```bash
cd backend
python local_server.py
```
API running at **`http://localhost:8000/api`**.

---

## ☁️ AWS Cloud Deployment
```bash
cd backend
sam build
sam deploy --guided
```
See [DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md) for full instructions.

---

## 📖 Documentation
- [Architecture & Viva Defense Guide](docs/ARCHITECTURE.md)
- [REST API Specification](docs/API_SPEC.md)
- [Judging Demo Walkthrough Script](docs/DEMO_SCRIPT.md)
- [AWS SAM Template](backend/template.yaml)
- [DynamoDB Schema](backend/dynamodb/schema.json)
