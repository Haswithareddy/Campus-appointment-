import React, { useState } from 'react';
import { 
  GraduationCap, 
  Briefcase, 
  ShieldCheck, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  Zap,
  Building,
  KeyRound,
  AlertTriangle,
  ShieldAlert
} from 'lucide-react';

// Authorized Demo Rosters
export const DEMO_USERS = {
  student: {
    name: 'Aisha Fatima',
    email: 'aisha.fatima@campus.edu',
    password: 'password123',
    role: 'student',
    studentId: 'STU-8842',
    department: 'Computer Science & Engineering',
    avatar: '👩‍🎓'
  },
  faculty: {
    name: 'Priya Sharma',
    email: 'priya.sharma@campus.edu',
    password: 'password123',
    role: 'staff',
    staffId: 'STF-001',
    designation: 'Senior Immigration Advisor',
    department: 'Global Education Center (Counter 4)',
    avatar: '👩‍💼'
  },
  admin: {
    name: 'Dr. Marcus Vance',
    email: 'admin.vance@campus.edu',
    password: 'password123',
    role: 'admin',
    adminId: 'ADM-101',
    designation: 'Dean of Student Affairs & Operations',
    department: 'Campus Administration Wing',
    avatar: '👨‍💼'
  }
};

// Known Student Email Lists for Strict Role Boundary Checking
const KNOWN_STUDENT_EMAILS = [
  'aisha.fatima@campus.edu',
  'student@campus.edu',
  'jordan.lee@campus.edu',
  'carlos.m@campus.edu',
  'samantha.r@campus.edu',
  'alex.chen@campus.edu',
  'michael.b@campus.edu'
];

// Known Staff Roster
const KNOWN_STAFF_EMAILS = [
  'priya.sharma@campus.edu',
  'marcus.vance@campus.edu',
  'elena.rostova@campus.edu',
  'david.chen@campus.edu',
  'sarah.jenkins@campus.edu',
  'staff@campus.edu',
  'faculty@campus.edu'
];

// Known Admin Roster
const KNOWN_ADMIN_EMAILS = [
  'admin.vance@campus.edu',
  'admin@campus.edu',
  'registrar.admin@campus.edu',
  'dean@campus.edu',
  'operations.admin@campus.edu'
];

export default function LoginPortal({ onLoginSuccess, onContinueAsGuest }) {
  const [selectedRole, setSelectedRole] = useState('student'); // 'student', 'faculty', 'admin'
  const [email, setEmail] = useState(DEMO_USERS.student.email);
  const [password, setPassword] = useState(DEMO_USERS.student.password);
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleRoleChange = (role) => {
    setSelectedRole(role);
    setError('');
    const demo = DEMO_USERS[role];
    setEmail(demo.email);
    setPassword(demo.password);
  };

  const handleLogin = (e) => {
    e?.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      const cleanEmail = email.trim().toLowerCase();
      const cleanPassword = password.trim();

      if (!cleanEmail || !cleanPassword) {
        setError('Please enter your college email and password.');
        setIsLoading(false);
        return;
      }

      if (cleanPassword !== 'password123' && cleanPassword.length < 4) {
        setError('Invalid password. For demonstration, use: password123');
        setIsLoading(false);
        return;
      }

      // ==========================================
      // 1. STRICT STUDENT TAB VALIDATION
      // ==========================================
      if (selectedRole === 'student') {
        // If an explicit staff or admin email is entered on student tab
        if (KNOWN_STAFF_EMAILS.includes(cleanEmail)) {
          setError(`⚠️ "${email}" is registered as a Faculty/Staff account. Please switch to the "Faculty / Staff" tab above to sign in to your counter desk.`);
          setIsLoading(false);
          return;
        }
        if (KNOWN_ADMIN_EMAILS.includes(cleanEmail)) {
          setError(`⚠️ "${email}" is registered as an Administrator account. Please switch to the "Admin" tab above.`);
          setIsLoading(false);
          return;
        }

        let userProfile = {
          name: cleanEmail.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          email: email,
          role: 'student',
          studentId: `STU-${Math.floor(1000 + Math.random() * 9000)}`,
          department: 'Undergraduate Division',
          avatar: '🎓'
        };

        if (cleanEmail === DEMO_USERS.student.email.toLowerCase()) {
          userProfile = DEMO_USERS.student;
        }

        setIsLoading(false);
        onLoginSuccess(userProfile);
        return;
      }

      // ==========================================
      // 2. STRICT FACULTY / STAFF TAB VALIDATION
      // ==========================================
      if (selectedRole === 'faculty') {
        // CRITICAL CHECK: Reject student emails trying to access staff portal!
        const isStudentEmail = KNOWN_STUDENT_EMAILS.includes(cleanEmail) || 
                               cleanEmail.startsWith('stu-') || 
                               cleanEmail.includes('student');

        if (isStudentEmail) {
          setError(`⛔ Access Denied: "${email}" is recognized as a STUDENT email. You cannot log into the Faculty/Staff Counter Desk with a student account. Please use an authorized faculty email (e.g. priya.sharma@campus.edu) or switch to the Student Portal tab.`);
          setIsLoading(false);
          return;
        }

        // Check if recognized faculty/staff or faculty domain
        const isStaff = KNOWN_STAFF_EMAILS.includes(cleanEmail) || 
                        cleanEmail.includes('faculty') || 
                        cleanEmail.includes('staff') || 
                        cleanEmail.includes('prof') || 
                        cleanEmail.includes('advisor') || 
                        cleanEmail.includes('registrar') || 
                        cleanEmail.endsWith('@staff.campus.edu');

        if (!isStaff && !cleanEmail.endsWith('.edu')) {
          setError(`⛔ Access Denied: "${email}" is not authorized on the Faculty/Staff directory. Please use authorized staff credentials (e.g. priya.sharma@campus.edu or staff@campus.edu).`);
          setIsLoading(false);
          return;
        }

        let userProfile = {
          name: cleanEmail.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          email: email,
          role: 'staff',
          staffId: `STF-${Math.floor(100 + Math.random() * 900)}`,
          designation: 'Service Desk Officer',
          department: 'Academic & Student Services Desk',
          avatar: '👩‍💼'
        };

        if (cleanEmail === DEMO_USERS.faculty.email.toLowerCase()) {
          userProfile = DEMO_USERS.faculty;
        } else if (cleanEmail === 'marcus.vance@campus.edu') {
          userProfile = {
            name: 'Marcus Vance',
            email: 'marcus.vance@campus.edu',
            role: 'staff',
            staffId: 'STF-002',
            designation: 'Assistant Registrar',
            department: "Registrar's Office (Counters 1 & 2)",
            avatar: '👨‍💼'
          };
        } else if (cleanEmail === 'elena.rostova@campus.edu') {
          userProfile = {
            name: 'Elena Rostova',
            email: 'elena.rostova@campus.edu',
            role: 'staff',
            staffId: 'STF-003',
            designation: 'Financial Aid Counselor',
            department: 'Financial Aid & Bursar (Counter 3)',
            avatar: '👩‍💼'
          };
        }

        setIsLoading(false);
        onLoginSuccess(userProfile);
        return;
      }

      // ==========================================
      // 3. STRICT ADMIN TAB VALIDATION
      // ==========================================
      if (selectedRole === 'admin') {
        const isAdmin = KNOWN_ADMIN_EMAILS.includes(cleanEmail) || 
                        cleanEmail.startsWith('admin') || 
                        cleanEmail.includes('dean') || 
                        cleanEmail.endsWith('@admin.campus.edu');

        if (!isAdmin) {
          setError(`⛔ Access Denied: Administrator security clearance required. "${email}" does not have campus administrative privileges. Please use authorized admin credentials (e.g. admin.vance@campus.edu or admin@campus.edu).`);
          setIsLoading(false);
          return;
        }

        let userProfile = {
          name: cleanEmail.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          email: email,
          role: 'admin',
          adminId: `ADM-101`,
          designation: 'Dean of Student Affairs & Operations',
          department: 'Campus Administration Wing',
          avatar: '👨‍💼'
        };

        if (cleanEmail === DEMO_USERS.admin.email.toLowerCase()) {
          userProfile = DEMO_USERS.admin;
        }

        setIsLoading(false);
        onLoginSuccess(userProfile);
        return;
      }

      setIsLoading(false);
    }, 350);
  };

  const handleQuickDemoFill = (roleKey) => {
    setSelectedRole(roleKey);
    setError('');
    const demo = DEMO_USERS[roleKey];
    setEmail(demo.email);
    setPassword(demo.password);
    onLoginSuccess(demo);
  };

  return (
    <div style={{
      minHeight: '85vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem 1rem'
    }}>
      <div style={{
        maxWidth: 520,
        width: '100%',
        background: 'rgba(17, 24, 39, 0.85)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.12)',
        borderRadius: '24px',
        padding: '2.25rem',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(99, 102, 241, 0.15)',
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Glowing top accent line */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          background: selectedRole === 'student' 
            ? 'linear-gradient(90deg, #6366f1, #38bdf8)' 
            : selectedRole === 'faculty'
            ? 'linear-gradient(90deg, #10b981, #3b82f6)'
            : 'linear-gradient(90deg, #f43f5e, #a855f7)'
        }} />

        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <div style={{
            width: 48,
            height: 48,
            borderRadius: '14px',
            background: 'linear-gradient(135deg, #6366f1, #38bdf8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 0.75rem auto',
            boxShadow: '0 0 25px rgba(99, 102, 241, 0.5)'
          }}>
            <Sparkles size={26} color="#ffffff" />
          </div>

          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, color: '#ffffff', letterSpacing: '-0.02em', marginBottom: '0.35rem' }}>
            CampusFlow <span style={{ color: '#38bdf8' }}>AI</span> Portal
          </h2>
          <p style={{ fontSize: '0.88rem', color: '#9ca3af', margin: 0 }}>
            Sign in with your verified campus email credentials
          </p>
        </div>

        {/* 3 Role Selection Tabs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr 1fr',
          gap: '0.4rem',
          background: 'rgba(15, 23, 42, 0.7)',
          padding: '0.35rem',
          borderRadius: '14px',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          marginBottom: '1.5rem'
        }}>
          <button
            type="button"
            onClick={() => handleRoleChange('student')}
            style={{
              padding: '0.65rem 0.5rem',
              borderRadius: '10px',
              border: selectedRole === 'student' ? '1px solid rgba(99, 102, 241, 0.5)' : '1px solid transparent',
              background: selectedRole === 'student' ? 'linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(30, 41, 59, 0.8))' : 'transparent',
              color: selectedRole === 'student' ? '#ffffff' : '#9ca3af',
              fontWeight: 700,
              fontSize: '0.82rem',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.3rem',
              transition: 'all 0.2s ease'
            }}
          >
            <GraduationCap size={18} color={selectedRole === 'student' ? '#818cf8' : '#64748b'} />
            <span>Student Portal</span>
          </button>

          <button
            type="button"
            onClick={() => handleRoleChange('faculty')}
            style={{
              padding: '0.65rem 0.5rem',
              borderRadius: '10px',
              border: selectedRole === 'faculty' ? '1px solid rgba(16, 185, 129, 0.5)' : '1px solid transparent',
              background: selectedRole === 'faculty' ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.25), rgba(30, 41, 59, 0.8))' : 'transparent',
              color: selectedRole === 'faculty' ? '#ffffff' : '#9ca3af',
              fontWeight: 700,
              fontSize: '0.82rem',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.3rem',
              transition: 'all 0.2s ease'
            }}
          >
            <Briefcase size={18} color={selectedRole === 'faculty' ? '#34d399' : '#64748b'} />
            <span>Faculty / Staff</span>
          </button>

          <button
            type="button"
            onClick={() => handleRoleChange('admin')}
            style={{
              padding: '0.65rem 0.5rem',
              borderRadius: '10px',
              border: selectedRole === 'admin' ? '1px solid rgba(244, 63, 94, 0.5)' : '1px solid transparent',
              background: selectedRole === 'admin' ? 'linear-gradient(135deg, rgba(244, 63, 94, 0.25), rgba(30, 41, 59, 0.8))' : 'transparent',
              color: selectedRole === 'admin' ? '#ffffff' : '#9ca3af',
              fontWeight: 700,
              fontSize: '0.82rem',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.3rem',
              transition: 'all 0.2s ease'
            }}
          >
            <ShieldCheck size={18} color={selectedRole === 'admin' ? '#fda4af' : '#64748b'} />
            <span>Admin Portal</span>
          </button>
        </div>

        {/* Error Alert Banner with distinct styling */}
        {error && (
          <div style={{
            background: 'rgba(239, 68, 68, 0.18)',
            border: '1px solid rgba(239, 68, 68, 0.5)',
            borderRadius: '12px',
            padding: '0.85rem 1rem',
            color: '#fca5a5',
            fontSize: '0.84rem',
            lineHeight: 1.45,
            marginBottom: '1.25rem',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '0.5rem'
          }}>
            <ShieldAlert size={18} color="#ef4444" style={{ flexShrink: 0, marginTop: 2 }} />
            <div>{error}</div>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin}>
          {/* Role specific hint */}
          <div style={{
            fontSize: '0.76rem',
            color: selectedRole === 'faculty' ? '#34d399' : selectedRole === 'admin' ? '#fda4af' : '#a5b4fc',
            background: 'rgba(15, 23, 42, 0.5)',
            padding: '0.45rem 0.75rem',
            borderRadius: '8px',
            marginBottom: '1rem',
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}>
            {selectedRole === 'student' && "🎓 Enter your student email (e.g. aisha.fatima@campus.edu)"}
            {selectedRole === 'faculty' && "🏛️ Enter authorized faculty/staff email (e.g. priya.sharma@campus.edu). Student emails will be rejected."}
            {selectedRole === 'admin' && "🛡️ Enter campus administrator email (e.g. admin.vance@campus.edu)"}
          </div>

          {/* College Email Input */}
          <div style={{ marginBottom: '1.15rem' }}>
            <label style={{
              display: 'block',
              fontSize: '0.82rem',
              fontWeight: 600,
              color: '#e2e8f0',
              marginBottom: '0.4rem'
            }}>
              {selectedRole === 'student' ? 'Student College Email' : selectedRole === 'faculty' ? 'Faculty / Staff College Email' : 'Admin Security Email'}
            </label>
            <div style={{ position: 'relative' }}>
              <div style={{
                position: 'absolute',
                left: '0.9rem',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#64748b'
              }}>
                <Mail size={17} />
              </div>
              <input
                type="email"
                required
                className="input-text"
                style={{ paddingLeft: '2.5rem' }}
                placeholder={selectedRole === 'student' ? 'student@campus.edu' : selectedRole === 'faculty' ? 'faculty@campus.edu' : 'admin@campus.edu'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          {/* Password Input */}
          <div style={{ marginBottom: '1.15rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
              <label style={{ fontSize: '0.82rem', fontWeight: 600, color: '#e2e8f0' }}>
                Password
              </label>
              <a href="#forgot" onClick={(e) => { e.preventDefault(); alert('Default demo password for all accounts is: password123'); }} style={{ fontSize: '0.75rem', color: '#38bdf8' }}>
                Default: password123
              </a>
            </div>
            <div style={{ position: 'relative' }}>
              <div style={{
                position: 'absolute',
                left: '0.9rem',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#64748b'
              }}>
                <Lock size={17} />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                className="input-text"
                style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{
                  position: 'absolute',
                  right: '0.8rem',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'transparent',
                  border: 'none',
                  color: '#64748b',
                  cursor: 'pointer',
                  padding: 0
                }}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Remember Me */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', cursor: 'pointer', fontSize: '0.8rem', color: '#9ca3af' }}>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                style={{ accentColor: '#6366f1', borderRadius: '4px' }}
              />
              Remember on this campus device
            </label>

            <span style={{ fontSize: '0.75rem', color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              <CheckCircle2 size={12} /> Campus SSO Active
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className={`btn ${selectedRole === 'admin' ? 'btn-emergency' : selectedRole === 'faculty' ? 'btn-success' : 'btn-primary'}`}
            style={{ width: '100%', padding: '0.8rem', fontSize: '0.95rem' }}
          >
            {isLoading ? (
              <span>Verifying Role Credentials...</span>
            ) : (
              <>
                <span>Sign In to {selectedRole === 'student' ? 'Student Hub' : selectedRole === 'faculty' ? 'Staff Desk' : 'Admin Control'}</span>
                <ArrowRight size={17} />
              </>
            )}
          </button>
        </form>

        {/* 1-Click Quick Demo Login Pill Bar */}
        <div style={{
          marginTop: '1.5rem',
          paddingTop: '1.25rem',
          borderTop: '1px solid rgba(255, 255, 255, 0.08)'
        }}>
          <div style={{ fontSize: '0.75rem', color: '#9ca3af', fontWeight: 600, marginBottom: '0.65rem', textAlign: 'center' }}>
            ⚡ 1-Click Authorized Role Presentation Logins:
          </div>

          <div style={{ display: 'flex', gap: '0.4rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              type="button"
              onClick={() => handleQuickDemoFill('student')}
              style={{
                background: 'rgba(99, 102, 241, 0.12)',
                border: '1px solid rgba(99, 102, 241, 0.3)',
                color: '#a5b4fc',
                padding: '0.35rem 0.65rem',
                borderRadius: '8px',
                fontSize: '0.76rem',
                cursor: 'pointer',
                fontWeight: 600,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
            >
              👩‍🎓 Aisha (Student)
            </button>

            <button
              type="button"
              onClick={() => handleQuickDemoFill('faculty')}
              style={{
                background: 'rgba(16, 185, 129, 0.12)',
                border: '1px solid rgba(16, 185, 129, 0.3)',
                color: '#6ee7b7',
                padding: '0.35rem 0.65rem',
                borderRadius: '8px',
                fontSize: '0.76rem',
                cursor: 'pointer',
                fontWeight: 600,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
            >
              👩‍💼 Priya (Faculty - Counter 4)
            </button>

            <button
              type="button"
              onClick={() => handleQuickDemoFill('admin')}
              style={{
                background: 'rgba(244, 63, 94, 0.12)',
                border: '1px solid rgba(244, 63, 94, 0.3)',
                color: '#fda4af',
                padding: '0.35rem 0.65rem',
                borderRadius: '8px',
                fontSize: '0.76rem',
                cursor: 'pointer',
                fontWeight: 600,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
            >
              👨‍💼 Dr. Vance (Admin)
            </button>
          </div>
        </div>

        {/* Public browse fallback */}
        <div style={{ textAlign: 'center', marginTop: '1.25rem' }}>
          <button
            type="button"
            onClick={onContinueAsGuest}
            style={{
              background: 'transparent',
              border: 'none',
              color: '#64748b',
              fontSize: '0.78rem',
              cursor: 'pointer',
              textDecoration: 'underline'
            }}
          >
            Or browse campus service directory without signing in
          </button>
        </div>
      </div>
    </div>
  );
}
