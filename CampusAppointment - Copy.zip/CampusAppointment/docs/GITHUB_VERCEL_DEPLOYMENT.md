# CampusFlow AI — GitHub & Vercel 1-Click Deployment Guide

Follow these simple steps to push **CampusFlow AI** to your GitHub account and deploy it live on **Vercel**.

---

## 🐙 Step 1: Push Code to GitHub

### 1.1 Create a New GitHub Repository
1. Go to [github.com/new](https://github.com/new).
2. Name your repository: `CampusFlow-AI` (or any name you prefer).
3. Choose **Public** or **Private**.
4. Leave *"Initialize this repository with a README"* **unchecked** (we already have a complete README).
5. Click **Create repository**.

### 1.2 Push from Your Terminal
Open PowerShell / Command Prompt and run:

```bash
# Navigate to the project directory
cd "C:\Users\Reddy Sekhar\.gemini\antigravity-ide\scratch\campusflow-ai"

# Rename branch to main
git branch -M main

# Link to your newly created GitHub repository (replace with your actual URL)
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/CampusFlow-AI.git

# Push the complete codebase
git push -u origin main
```

---

## ▲ Step 2: Deploy on Vercel (1-Click Hosting)

### 2.1 Import to Vercel
1. Log in to [vercel.com](https://vercel.com).
2. Click **Add New...** > **Project**.
3. Under **Import Git Repository**, select your `CampusFlow-AI` repository.

### 2.2 Configure Project Settings on Vercel
- **Framework Preset**: `Vite` (Vercel automatically detects this from `vercel.json`).
- **Root Directory**: `./` (leave as default) or `frontend`.
- **Build Command**: `cd frontend && npm install && npm run build` (auto-configured by `vercel.json`).
- **Output Directory**: `frontend/dist`.

### 2.3 Deploy
Click **Deploy**! In ~40 seconds, Vercel will give you a live production URL:
> **`https://campusflow-ai-yourname.vercel.app`**

---

## 🌐 Alternative: Instant Local Run

To preview or demo locally before or during presentations:
```bash
cd frontend
npm install
npm run dev
```
Open **`http://localhost:3000/`** in your browser.

---

## 📋 Comprehensive Interactive Feature Checklist

Every single button and flow is fully functional and synchronized:

- [x] **Front Page College Login Gateway**:
  - Student, Faculty, and Admin login tabs with strict college email (`@campus.edu`) validation.
  - 1-Click test credential pills for instant demonstration:
    - 👩‍🎓 `Aisha (Student)` -> Signs in to Student Hub.
    - 👩‍💼 `Priya (Faculty/Counter 4)` -> Signs in to Staff Desk.
    - 👨‍💼 `Dr. Vance (Admin)` -> Signs in to Admin Command Center.
- [x] **Role-Based Security Boundary (RBAC)**:
  - Blocks student emails from logging into Faculty or Admin portals.
  - Displays access-restricted alert if a student attempts to navigate to the Staff Desk or Admin Workspace.
- [x] **Natural Language Bedrock AI Navigator**:
  - "What do you need help with?" search bar.
  - Suggestion pills ("Urgent Visa", "Transcripts", "Lost ID", "Scholarship Hold").
  - Structured intent banner with category and urgency extraction.
  - "Clear Filter" button.
- [x] **Verified Service Cards**:
  - Displays Office, Room, Counter, Operating Hours, and Required Documents checklist with interactive checkboxes.
  - **"Join Live Queue"** button: Issues live virtual ticket (`REG-XXX`), plays confetti, advances queue.
  - **"Book Slot"** button: Opens appointment modal with calendar and time slot selection.
  - **"Digital Form"** button: Opens digital request submission with Amazon S3 document upload simulation.
  - **"Apply Emergency Priority"** button: Enforces strict 2–3 daily quota cap, requires deadline date, reason, and S3 upload.
- [x] **Student Problem & Inquiry Hub**:
  - **"Report Campus Problem / Inquiry"** red button at the top of Student Hub.
  - Submits custom issues, routes to correct counter, and displays in student's live inquiry feed.
- [x] **Staff Counter Workspace**:
  - Counter selector (Counter 4 Visa, Counters 1 & 2 Registrar, Counter 3 Bursar, Counter 6 ID Cards).
  - Counter Duty active/break toggle button.
  - 3 Workspace Tabs: `Standard Queue`, `Emergency Queue`, `Student Problems`.
  - **"Call to Desk"** button.
  - **"✍️ Signature Completed & Stamp Issued"** button: Finalizes ticket and **dynamically reduces waiting times for everyone else in line**.
  - Staff notes textarea with **"Save Note"** and **"Mark Resolved"** buttons.
- [x] **Admin Incident Command Center**:
  - 4 Live KPI metric cards.
  - Live Real-Time Activity & Signature broadcast stream.
  - Campus-wide Student Problem Log with Category, Urgency, and Status filters.
  - Regulated Emergency Quota Allocator with live daily limit stepper for each department.
- [x] **Navbar Controls**:
  - Quick Demo buttons ("Demo: Urgent Visa", "Demo: Transcript").
  - Role switcher pills with access checks.
  - User profile avatar & details.
  - "Reset Data" button to restore a clean baseline dataset.
