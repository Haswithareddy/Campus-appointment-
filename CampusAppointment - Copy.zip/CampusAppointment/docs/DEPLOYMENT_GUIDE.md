# CampusFlow AI — Setup & AWS Deployment Guide

This guide explains how to run CampusFlow AI **locally for rapid prototype presentation** and how to **deploy the production serverless backend to AWS**.

---

## 1. Quick Local Setup (Instant Demo Execution)

### Step 1: Start Frontend
```bash
cd frontend
npm install
npm run dev
```
The modern UI will be accessible at: **`http://localhost:3000`**

### Step 2: (Optional) Start Python Local Backend Server
```bash
cd backend
python local_server.py
```
Runs the local REST API server simulating Bedrock intent parsing and DynamoDB storage on **`http://localhost:8000/api`**.

---

## 2. AWS Serverless Production Deployment

### Prerequisites
- AWS CLI configured (`aws configure` with Administrator or Serverless deployment IAM role)
- AWS SAM CLI installed (`sam --version`)
- Python 3.11+

### Step 1: Deploy with AWS SAM
```bash
cd backend
sam build
sam deploy --guided
```
When prompted by SAM CLI:
- **Stack Name**: `campusflow-ai`
- **AWS Region**: `us-east-1` (or your preferred region with Amazon Bedrock enabled)
- **Confirm changes before deploy**: `Y`
- **Allow SAM CLI IAM role creation**: `Y`
- **Save arguments to configuration file**: `Y`

SAM will automatically provision:
- 1 × Amazon API Gateway REST API with CORS
- 5 × AWS Lambda Functions (Navigator, Queue, Emergency, Appointments, Digital Requests)
- 6 × Amazon DynamoDB Tables with on-demand capacity
- 1 × Amazon S3 Bucket for student supporting documents
- IAM Roles with least-privilege Bedrock and DynamoDB policies.

### Step 2: Enable Bedrock Claude 3 Model Access
In the AWS Management Console:
1. Navigate to **Amazon Bedrock** > **Model access**.
2. Request access for **Anthropic: Claude 3 Sonnet** (or Amazon Titan Text).
3. Access is typically approved instantly.

### Step 3: Seed DynamoDB Tables
Run the Python seeder script:
```bash
python seed_dynamodb.py
```

### Step 4: Configure Frontend with Live AWS Endpoint
In `frontend/`:
Create a `.env` file:
```env
VITE_API_URL=https://{YOUR_API_ID}.execute-api.us-east-1.amazonaws.com/Prod/api
```
Build and deploy the frontend:
```bash
npm run build
```
You can deploy the build folder to **AWS S3 + CloudFront** or **AWS Amplify Hosting**.
