# CampusFlow AI — AWS Architecture & Viva Defense Guide

## 1. Problem Statement & Executive Summary
**“The Appointment That Took All Morning.”**
Campus administrative services suffer from high information fragmentation: students do not know which counter handles their request, what prerequisite documents are mandatory, how long queues are, or whether appointments are required. This results in counter hopping, queue imbalance, and emergency requests getting lost in standard walk-in queues.

**CampusFlow AI** introduces a unified serverless solution combining **Amazon Bedrock** for structured natural language intent/urgency extraction, **Amazon DynamoDB** for authoritative operational data retrieval, **Amazon S3** for document upload verification, and a **Regulated 2–3 Slot Daily Emergency Quota Engine** to protect critical student deadlines without allowing unfair queue jumping.

---

## 2. End-to-End AWS Serverless Architecture

```mermaid
graph TD
    User([Student / Staff / Admin]) -->|HTTPS / REST| APIGW[Amazon API Gateway]

    subgraph Compute Layer ["Compute Layer (AWS Lambda)"]
        L_Nav["Navigator Lambda\n(Claude 3 Intent & Scoring)"]
        L_Queue["Queue Lambda\n(Wait Estimation & Token Dispenser)"]
        L_Emg["Emergency Lambda\n(2-3 Slot Daily Quota Enforcement)"]
        L_Doc["Digital Request Lambda\n(Presigned URL Generator)"]
        L_Appt["Appointments Lambda\n(Calendar Scheduler)"]
    end

    subgraph AI Layer ["Generative AI Layer"]
        Bedrock["Amazon Bedrock\n(Anthropic Claude 3 Sonnet)"]
    end

    subgraph Storage Layer ["Storage & Database Layer"]
        DDB_Services[("DynamoDB: Services")]
        DDB_Queues[("DynamoDB: Queues")]
        DDB_Emg[("DynamoDB: EmergencyRequests")]
        DDB_Staff[("DynamoDB: Staff")]
        DDB_Appt[("DynamoDB: Appointments")]
        S3_Docs[("Amazon S3: Student Documents")]
    end

    APIGW --> L_Nav
    APIGW --> L_Queue
    APIGW --> L_Emg
    APIGW --> L_Doc
    APIGW --> L_Appt

    L_Nav --> Bedrock
    L_Nav --> DDB_Services
    L_Nav --> DDB_Queues

    L_Queue --> DDB_Queues
    L_Queue --> DDB_Services

    L_Emg --> DDB_Emg
    L_Emg --> DDB_Services
    L_Emg --> DDB_Queues

    L_Doc --> S3_Docs
    L_Doc --> DDB_Services
```

---

## 3. Key Architectural Decisions & Viva Defense Points

### Q1: Why not let the LLM directly answer campus operational questions?
**Answer**:
Large Language Models hallucinate office hours, room numbers, and counter assignments. In CampusFlow AI, the LLM (**Amazon Bedrock Claude 3**) is used **strictly for intent, keyword, and urgency extraction**. It parses messy human language into a clean JSON structure (`detectedCategory`, `isUrgent`, `extractedDeadline`, `keywords`). The backend Lambda then performs an **authoritative lookup against DynamoDB** for real office locations, actual required documents, active staff on duty, and live queue counts.

### Q2: How does the Emergency Priority mechanism work and how is abuse prevented?
**Answer**:
1. **Configurable Daily Quota**: Each service has a strict limit of **2 to 3 protected emergency slots per day** (configurable by admins).
2. **Mandatory Proof**: Students must supply a specific justification reason, verifiable deadline date, and supporting documentation (uploaded to Amazon S3).
3. **Authoritative Staff Verification**: The AI only tags potential urgency; human staff review the evidence in the Staff Portal before granting priority access.
4. **Graceful Fallbacks**: If the quota of 2–3 is exhausted, the system refuses queue skips and offers high-priority next-day appointments or expedited digital submissions.

### Q3: What is the Transparent Queue Wait Time formula?
**Answer**:
Instead of claiming black-box machine learning without historical datasets, we use a deterministic, transparent formula:
$$\text{Estimated Wait (minutes)} = \frac{\text{Active Waiting Students} \times \text{Average Service Duration (min)}}{\max(1, \text{Active Duty Staff at Counter})}$$
This provides predictable, honest waiting times updated in real time as staff toggle duty status.

### Q4: Why use S3 Pre-signed URLs for document uploads?
**Answer**:
Pre-signed URLs allow the client browser to upload large supporting documents (passports, transcripts, embassy receipts) directly to Amazon S3 securely without burdening API Gateway or Lambda memory limits.

---

## 4. DynamoDB Table Design & Indexes

| Table Name | Partition Key (HASH) | Sort Key (RANGE) | GSIs / Secondary Indexes |
| :--- | :--- | :--- | :--- |
| `CampusFlow_Services` | `serviceId` (S) | - | `CategoryIndex` (`category`) |
| `CampusFlow_Queues` | `ticketId` (S) | - | `ServiceStatusIndex` (`serviceId`, `status`) |
| `CampusFlow_EmergencyRequests` | `emergencyId` (S) | - | `ServiceDateIndex` (`serviceId_date`, `status`) |
| `CampusFlow_Appointments` | `appointmentId` (S) | - | `ServiceDateIndex` (`serviceId`, `date`) |
| `CampusFlow_Staff` | `staffId` (S) | - | `ServiceIndex` (`serviceId`) |
| `CampusFlow_DigitalRequests` | `requestId` (S) | - | `StudentIndex` (`studentId`) |
