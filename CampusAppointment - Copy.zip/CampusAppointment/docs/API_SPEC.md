# CampusFlow AI — REST API Specification

Base URL (Local): `http://localhost:8000/api`  
Base URL (AWS Production): `https://{api-id}.execute-api.{region}.amazonaws.com/Prod/api`

---

## 1. Natural Language Service Navigator
- **Endpoint**: `POST /api/navigator`
- **Description**: Invokes Bedrock Claude 3 to extract structured intent and urgency from natural language, then retrieves matched services from DynamoDB.
- **Request Body**:
```json
{
  "query": "I need a visa-related document urgently because my visa appointment is tomorrow morning."
}
```
- **Response (`200 OK`)**:
```json
{
  "intent": {
    "detectedCategory": "International Students",
    "isUrgent": true,
    "urgencyReason": "Detected impending deadline or urgent operational keywords",
    "recommendedAction": "EMERGENCY_PRIORITY_OR_APPOINTMENT"
  },
  "matches": [
    {
      "serviceId": "SRV-INT-001",
      "name": "International Visa Letter & Travel Signature",
      "category": "International Students",
      "office": "Global Education Center (Building G, 2nd Floor)",
      "counter": "Counter 4 (Visa & Immigration)",
      "avgDurationMinutes": 12,
      "estimatedWaitTime": 6,
      "emergencyQuotaPerDay": 3,
      "emergencySlotsUsedToday": 1,
      "requiredDocuments": [
        "Valid Passport Copy",
        "Form I-20 or DS-2019 (Current)",
        "Proof of Next-Day Embassy/Visa Interview (for Emergency)"
      ]
    }
  ]
}
```

---

## 2. Emergency Priority (Protected 2-3 Slot Quota)
- **Endpoint**: `POST /api/emergency`
- **Description**: Verifies daily quota (max 2-3/day), checks deadline justification, and allocates an emergency priority token.
- **Request Body**:
```json
{
  "serviceId": "SRV-INT-001",
  "studentName": "Aisha Fatima",
  "studentId": "STU-8842",
  "email": "aisha.f@campus.edu",
  "deadline": "2026-08-23",
  "reason": "Consulate visa interview scheduled for tomorrow at 8:30 AM.",
  "supportingDocName": "embassy_appointment_aisha.pdf",
  "supportingDocUrl": "https://campusflow-docs.s3.amazonaws.com/embassy_aisha.pdf"
}
```
- **Response (`201 Created` — Slot Available)**:
```json
{
  "success": true,
  "message": "Emergency Priority Slot 2/3 reserved successfully!",
  "ticket": {
    "ticketId": "EMG-INT-002",
    "serviceId": "SRV-INT-001",
    "isEmergency": true,
    "position": 1,
    "status": "PENDING_VERIFICATION"
  },
  "quota": {
    "used": 2,
    "limit": 3,
    "remaining": 1
  }
}
```
- **Response (`409 Conflict` — Quota Exhausted)**:
```json
{
  "success": false,
  "error": "QUOTA_EXHAUSTED",
  "message": "Daily protected emergency quota limit of 3 reached for International Visa Letter & Travel Signature.",
  "quota": { "used": 3, "limit": 3, "remaining": 0 },
  "fallbackOptions": [
    { "type": "BOOK_NEXT_APPOINTMENT", "label": "Book Priority Morning Appointment Tomorrow" },
    { "type": "DIGITAL_SUBMISSION", "label": "Submit Expedited Digital Request with Supporting Documents" }
  ]
}
```

---

## 3. Queue Management
- **Endpoint**: `POST /api/queue`
- **Request Body**:
```json
{
  "serviceId": "SRV-REG-001",
  "studentName": "Jordan Lee",
  "studentId": "STU-5512"
}
```
- **Response (`201 Created`)**:
```json
{
  "ticketId": "REG-412",
  "serviceId": "SRV-REG-001",
  "status": "WAITING",
  "position": 7,
  "estimatedWaitMinutes": 28,
  "counter": "Counters 1 & 2"
}
```

---

## 4. Digital Request & S3 Document Upload
- **Endpoint**: `POST /api/digital/presigned-url`
- **Request Body**:
```json
{
  "filename": "passport_scan.pdf",
  "fileType": "application/pdf"
}
```
- **Response (`200 OK`)**:
```json
{
  "uploadUrl": "https://campusflow-student-docs.s3.us-east-1.amazonaws.com/student_uploads/172432_passport_scan.pdf?X-Amz-Signature=...",
  "fileKey": "student_uploads/172432_passport_scan.pdf",
  "expiresInSeconds": 900
}
```
