# CampusFlow AI — Hackathon Presentation & Live Demo Script

Use this script to present CampusFlow AI during hackathon judging and live demonstrations.

---

## 🎬 Presentation Introduction (30 seconds)
> *"Judges, we've all experienced 'The Appointment That Took All Morning' — arriving on campus, waiting 45 minutes in line at the registrar, only to be told you're at the wrong counter, missing a required document, or that your urgent deadline wasn't prioritized.*
> 
> *Today, we present **CampusFlow AI**: a serverless smart campus orchestrator powered by Amazon Bedrock, DynamoDB, Lambda, and S3, featuring transparent wait time formulas and a regulated 2-to-3 slot emergency quota engine."*

---

## 🌟 Demo Scenario 1: The Urgent Visa Request (Emergency Priority Flow)

1. **Step 1: Student Input**
   - Click the top navigation button: **`Demo: Urgent Visa (Emergency Flow)`** or type:
     > *"I need a visa-related document urgently because my visa appointment is tomorrow morning."*
   - Click **Find Service**.

2. **Step 2: Bedrock AI Intent Analysis**
   - Show the judges the structured intent banner:
     - Model: `anthropic.claude-3`
     - Detected Category: `International Students`
     - Urgency Flagged: `⚡ High Urgency Flagged (Impending visa interview)`
   - Point out that the LLM did not hallucinate campus facts; the system retrieved the verified **Global Education Center (Building G, Counter 4)** and required checklist (Passport, Form I-20, Embassy interview proof).

3. **Step 3: Emergency Quota Allocation**
   - Show the Emergency Quota indicator on the card: **`1/3 Slots Used Today (2 Remaining)`**.
   - Click **Apply Emergency Priority**.
   - Show the modal:
     - Form pre-fills student Aisha Fatima, tomorrow's deadline, and stated reason.
     - Document upload via **Amazon S3 Presigned URL**.
   - Click **Request Emergency Slot**.
   - Confetti triggers! A priority token **`EMG-INT-002`** is issued.

4. **Step 4: Staff Verification**
   - Click **Staff Desk** in the top navigation bar.
   - Switch to **Counter 4 (Visa & Immigration Desk)**.
   - View Aisha's ticket under **Priority Emergency Queue**.
   - Review her stated reason and S3 attachment.
   - Click **Approve Priority Slot** and then **Call Emergency Student to Desk**.
   - Return to Student view to see the live ticket badge change to **"NOW SERVING AT COUNTER!"**

---

## 📄 Demo Scenario 2: Standard Fairness & Digital Fulfillment

1. **Step 1: Normal Transcript Request**
   - Click **Demo: Transcript Request** or type:
     > *"I need my official academic transcript stamped for graduate school application."*
   - System matches **Registrar's Office (Counters 1 & 2)**.
   - Shows transparent wait time: **~24 min wait** (6 in queue ÷ 2 active staff × 8 mins).

2. **Step 2: Digital Form Bypass**
   - Instead of standing in line, click **Digital Form**.
   - Submit digital transcript request with uploaded fee receipt.
   - Instant tracking ID generated: **`DIG-98210`**. No physical queuing needed!

---

## 📊 Demo Scenario 3: Admin Operations & Quota Control

1. **Step 1: Switch to Admin Dashboard**
   - Click **Admin** in the top navigation.
   - View real-time KPI tiles: Total waiting students across 6 counters, active staff counters, and digital diversion rate.

2. **Step 2: Emergency Quota Policy Adjustment**
   - Scroll to the **Regulated Emergency Quota Allocator**.
   - Demonstrate how campus administrators can adjust daily emergency caps from **3 to 2 slots** to prevent standard queue starvation during peak periods.

---

## 🏆 Key Takeaways for Judges
1. **No LLM Hallucinations**: Bedrock extracts intent; DynamoDB supplies verified ground truth.
2. **Fairness Guaranteed**: Strict 2–3 slot daily quota prevents infinite queue jumping.
3. **Transparent Waiting Times**: Deterministic, understandable wait time engine.
4. **AWS Serverless Native**: Scalable, cost-effective, zero-server maintenance.
